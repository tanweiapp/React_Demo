#仿简书的一个练习项目

##安装依赖包
+ `yarn`
##项目启动
+ `npm start`
#####或者
+ `yarn start`