// React模块编译JSX语法
import React from 'react';
import ReactDOM from 'react-dom';
import App from './App.js';
//import './statics/iconfont/iconfont'
//import  './style';



ReactDOM.render(<App/>, document.getElementById('root'));
