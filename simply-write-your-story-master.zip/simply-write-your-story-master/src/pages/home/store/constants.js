export const CHANGE_AUTHORS = 'home/CHANGE_AUTHORS';
export const CHANGE_PAGE = 'home/CHANGE_PAGE';
export const TOGGLE_TOP_SHOW = 'home/TOGGLE_TOP_SHOW';
export const CHANGE_HOME_DATA = 'home/CHANGE_HOME_DATA';
export const GET_MORE_ARTICLE_LIST = 'home/GET_MORE_ARTICLE_LIST';