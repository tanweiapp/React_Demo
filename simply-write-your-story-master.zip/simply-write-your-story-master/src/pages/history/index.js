import React, {PureComponent} from 'react';

class History extends PureComponent {
    render() {
        return (
            <h1>这是HISTORY页面new</h1>
        )
    }
}
export default History;